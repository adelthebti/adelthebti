import openai
import os

VLLM_API_URL = os.getenv("VLLM_API_URL", "http://vllm_container:8000")

client = openai.OpenAI(
    base_url=VLLM_API_URL,
    api_key="dummy-key"  
)

system = """
You are an assistant helping students make the best career choices and prepare for professional life. 
Your goal is to provide clear and relevant advice tailored to the aspirations and needs of students. 
Respond concisely based only on the provided context. \n\n
your answer should soley be based on the context, if it's not respond with i do not know \n\n
"""

print(system)

def generate_response(context, user_query):
    prompt = (
        
        f"Context:\n{context}\n"
        f"Question: {user_query}\n"
        "Answer:"
    )

    response = client.chat.completions.create(
        model="meta-llama/Llama-3.2-1B-Instruct",
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": prompt}
        ],
        temperature= 0.01,
        extra_body={"chat_format": "llama-2"}
    )

    return response.choices[0].message.content
