import os
import glob
from langchain.document_loaders import JSONLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain_community.vectorstores.milvus import Milvus  # Legacy API import

# Use the bilingual embedding model from HuggingFace
EMBEDDING_MODEL = 'Lajavaness/bilingual-embedding-large'
model_kwargs = {"trust_remote_code": True}

def main():
    # Define the folder containing your JSON files
    data_folder = os.path.abspath("data")
    
    # Find all JSON files in the folder
    json_files = glob.glob(os.path.join(data_folder, "*.json"))
    if not json_files:
        print(f"No JSON files found in folder: {data_folder}")
        return

    # Step 1: Load and preprocess all JSON files
    raw_documents = []
    for json_file in json_files:
        print(f"Loading JSON from: {json_file}")
        loader = JSONLoader(
            file_path=json_file,
            jq_schema=".[] | {page_content: .content, metadata: .metadata}",
            text_content=False
        )
        raw_documents.extend(loader.load())
    
    print(f"Loaded {len(raw_documents)} documents from {len(json_files)} JSON files.")

    # Step 2: Process documents to ensure the "page_content" is properly decoded
    documents = [
        Document(
            page_content=(
                doc.page_content.encode('utf-8').decode('unicode_escape')
                if isinstance(doc.page_content, str)
                else str(doc.page_content)
            ),
            metadata=doc.metadata
        )
        for doc in raw_documents
    ]

    # Step 3: Optionally split the documents into manageable chunks
    print("Splitting the documents into chunks...")
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunked_documents = text_splitter.split_documents(documents)
    print(f"Created {len(chunked_documents)} chunks.")

    # Step 4: Initialize embeddings using the bilingual model
    print(f"Initializing embeddings using model: {EMBEDDING_MODEL}")
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL, model_kwargs=model_kwargs)

    # Step 5: Connect to Milvus (using environment variables or defaults)
    milvus_host = os.getenv("MILVUS_HOST", "milvus-standalone")
    milvus_port = int(os.getenv("MILVUS_PORT", "19530"))
    connection_args = {"host": milvus_host, "port": milvus_port}

    print(f"Connecting to Milvus at {milvus_host}:{milvus_port}")

    # Step 6: Index the document chunks into Milvus
    vector_store = Milvus.from_documents(
        chunked_documents,
        embeddings,
        collection_name="json_collection",  # Adjust the collection name if needed
        connection_args=connection_args,
        index_params={"index_type": "IVF_FLAT", "metric_type": "L2"},
        primary_field="id",
        text_field="page_content",
        vector_field="embedding"
    )
    
    print("Ingestion complete. Documents have been indexed into Milvus.")

if __name__ == "__main__":
    print('going through embedding')
    main()
