import os
import chainlit as cl
from langchain_community.vectorstores.milvus import Milvus  # Legacy API import
from langchain_huggingface import HuggingFaceEmbeddings
from generator import generate_response


embedding_model_name = os.getenv("SENTENCE_TRANSFORMER_MODEL")
model_kwargs = {"trust_remote_code": True}
embeddings = HuggingFaceEmbeddings(model_name=embedding_model_name, model_kwargs=model_kwargs)

vector_store = Milvus(
    embedding_function=embeddings,
    collection_name="json_collection",
    connection_args={
        "host": os.getenv("MILVUS_HOST", "milvus-standalone"),
        "port": os.getenv("MILVUS_PORT", "19530")
    },
    index_params={"index_type": "IVF_FLAT", "metric_type": "L2"},
    primary_field="id",         
    text_field="page_content",           
    vector_field="embedding"     
)


@cl.on_message
async def on_message(message: cl.Message):
    print('hi')
    user_query = message.content

    retrieved_docs = vector_store.similarity_search(user_query, k=5)
    context = " ".join([doc.page_content for doc in retrieved_docs])
    print("Retrieved context:", context)
    
    if not context:
        context = "No relevant context found."
    
    
    response = generate_response(context, user_query)
    await cl.Message(content=response).send()

if __name__ == "__main__":
    cl.run()
