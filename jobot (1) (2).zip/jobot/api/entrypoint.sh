#!/bin/bash
set -e

#echo "Starting ingestion of PDFs into Milvus..."
#python ingest.py

echo "Starting Chainlit server..."
chainlit run main.py --host 0.0.0.0 --port 8000
